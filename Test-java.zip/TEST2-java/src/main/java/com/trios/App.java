/*HARSIMRANDEEP SINGH STid:21019003*/
package com.trios;
import jakarta.persistence.Query;
import jakarta.persistence.*;

import java.util.Scanner;

public class App
{
    private  static EntityManagerFactory emf= Persistence.createEntityManagerFactory("Track");
    public static void main( String[] args )
    {



        System.out.println("HIT FROM THE MENU Below");
        System.out.println("HIT 1 for SEARCHING PRICE");
        System.out.println("HIT 2 for UPDATE PRICE OF THE TRACK");
        System.out.println("HIT 3 TO CREATE A NEW MENU");



        Scanner input=new Scanner(System.in);
        System.out.println("ENTER OPTION: ");
        int option= Integer.parseInt(input.nextLine());

        if (option==1){
            System.out.println("ENTER Name: ");
            String Track_Name = input.nextLine();
            getPrice(Track_Name);
            System.out.println("DO YOU WANT TO MAKE MORE CHANGES HIT -> y/n ");
            String j= input.nextLine();
            if (j=="y" || j=="Y") {
                System.out.println("ENTER Name: ");
                String again = input.nextLine();
                getPrice(again);}
            else if (j=="n" || j=="N"){
                System.out.println("OK");
            }
            else
                System.out.println("INVALID INPUT");





        }
        else if (option==2){
            System.out.println("ENTER TrackID: ");
            int Track_Name = Integer.parseInt(input.nextLine());
            System.out.println("ENTER Price: ");
            int P_price= Integer.parseInt(input.nextLine());

            UpdateTrack(Track_Name,P_price);
            System.out.println("DO YOU WANT TO MAKE MORE CHANGES HIT-> y/n ");

            String j= input.nextLine();
            if (j=="y" || j=="Y") {
                System.out.println("ENTER TrackID: ");
                int Track_Namee = Integer.parseInt(input.nextLine());
                System.out.println("ENTER Price: ");
                int P_pricee= Integer.parseInt(input.nextLine());
                UpdateTrack(Track_Namee,P_pricee);
                }
            else if (j=="n" || j=="N"){
                System.out.println("OK");
            }
            else
                System.out.println("INVALID INPUT");

        }

        else if(option==3) {
            System.out.println("ENTER Name: ");
            String Track_Name = input.nextLine();
            System.out.println("ENTER Album ID: ");
            int Track_album = Integer.parseInt(input.nextLine());
            System.out.println("ENTER MediaTypeID: ");
            int T_mediatype = Integer.parseInt(input.nextLine());
            System.out.println("ENTER Genre ID: ");
            int G_ID = Integer.parseInt(input.nextLine());
            System.out.println("ENTER Composer ");
            String Cmpsr = input.nextLine();
            System.out.println("ENTER Millisecond ");
            int m_sec = Integer.parseInt(input.nextLine());
            System.out.println("ENTER Byte ");
            int bt = Integer.parseInt(input.nextLine());
            System.out.println("ENTER unitPrice ");
             int u_price = Integer.parseInt(input.nextLine());


            createTrack(Track_Name, Track_album, T_mediatype, G_ID   ,Cmpsr,m_sec, bt, u_price);


            System.out.println("DO YOU WANT TO MAKE MORE CHANGES HIT-> y/n ");

            String j= input.nextLine();
            if (j=="y" || j=="Y") {
                System.out.println("ENTER Name: ");
                String Track_Namee = input.nextLine();
                System.out.println("ENTER Album ID: ");
                int Track_albume = Integer.parseInt(input.nextLine());
                System.out.println("ENTER MediaTypeID: ");
                int T_mediatypee = Integer.parseInt(input.nextLine());
                System.out.println("ENTER Genre ID: ");
                int G_IDe = Integer.parseInt(input.nextLine());
                System.out.println("ENTER Composer ");
                String Cmpsre = input.nextLine();
                System.out.println("ENTER Millisecond ");
                int m_sece = Integer.parseInt(input.nextLine());
                System.out.println("ENTER Byte ");
                int bte = Integer.parseInt(input.nextLine());
                System.out.println("ENTER unitPrice ");
                int u_pricee = Integer.parseInt(input.nextLine());
                createTrack(Track_Namee, Track_albume, T_mediatypee, G_IDe   ,Cmpsre,m_sece, bte, u_pricee);
            }
            else if (j=="n" || j=="N"){
                System.out.println("OK");
            }
            else
                System.out.println("INVALID INPUT");


            }
        }



    public static void getPrice(String track_name) {
        EntityManager em = emf.createEntityManager();
        String query_string;
        try {
            Track tr =new Track();
            query_string = "select e from Track as t where TrackName=:name";
            Query q = em.createQuery(query_string);
            q.setParameter("name",track_name);
            q.executeUpdate();
            System.out.println("THE PRICE OF THE " + track_name + " IS = " + tr.getUnitPrice());

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            em.close();

        }
    }

        public static void UpdateTrack(int TrackID, int price){
            EntityManager em=emf.createEntityManager();
            EntityTransaction et=null;
            String query_string;
            try{
                et =em.getTransaction();
                et.begin();
                Track tr =new Track();
                query_string="Update Customers  set UnitPrice= "+price+" where TrackId=:id";
                Query q=em.createQuery(query_string);


                q.setParameter("id",TrackID);

                q.executeUpdate();
                em.persist(tr);
                et.commit();


            }catch(Exception ex){
                if(et !=null){
                    et.rollback();
                }
            }
            finally {
                em.close();

            }
        }


    public static void createTrack(
    String t_Name,
    int t_AlbumId,
    int t_MediaTypeId,
    int t_GenreId,
    String t_Composer,
    int t_Milliseconds,
    int t_Bytes,
    float t_UnitPrice)
                                      {
        EntityManager em= emf.createEntityManager();
        EntityTransaction et=null;
        try{

            et =em.getTransaction();
            et.begin();
            Track tr =new Track();

            tr.setName(t_Name);
            tr.setAlbumId(t_AlbumId);
            tr.setMediaTypeId(t_MediaTypeId);
            tr.setGenreId(t_GenreId);
            tr.setComposer(t_Composer);
            tr.setMilliseconds(t_Milliseconds);
            tr.setBytes(t_Bytes);
            tr.setUnitPrice(t_UnitPrice);


            em.persist(tr);
            et.commit();


        }catch (Exception ex){
            if(et !=null){
                et.rollback();
            }

        }
        finally {
            em.close();
        }

    }



// When a user wishes to update price of a track, obtain track id and the new price, and update the corresponding track.
// When a user wishes to create a new track, obtain all necessary details required. In this case, trackID is autogenerated, so there is no need to request user for a trackID.


    }

