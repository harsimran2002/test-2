package com.trios;

import jakarta.persistence.*;

@Entity
@Table(name="track")


public class Track {
    @Id
    @Column(name="TrackID",unique=true)
    int TrackId;
    @Column(name="Name")
    String Name;
    @Column(name="AlbumId")
    int AlbumId;
    @Column(name="MediaTypeId")
    int MediaTypeId;
    @Column(name="GenreId")
    int GenreId;
    @Column(name="Composer")
    String Composer;
    @Column(name="Milliseconds")
    int Milliseconds;
    @Column(name="Bytes")
    int Bytes;
    @Column(name="UnitPrice")
    float UnitPrice;


    public int getTrackId() {
        return TrackId;
    }

    public void setTrackId(int trackId) {
        TrackId = trackId;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public int getAlbumId() {
        return AlbumId;
    }

    public void setAlbumId(int albumId) {
        AlbumId = albumId;
    }

    public int getMediaTypeId() {
        return MediaTypeId;
    }

    public void setMediaTypeId(int mediaTypeId) {
        MediaTypeId = mediaTypeId;
    }

    public int getGenreId() {
        return GenreId;
    }

    public void setGenreId(int genreId) {
        GenreId = genreId;
    }

    public String getComposer() {
        return Composer;
    }

    public void setComposer(String composer) {
        Composer = composer;
    }

    public int getMilliseconds() {
        return Milliseconds;
    }

    public void setMilliseconds(int milliseconds) {
        Milliseconds = milliseconds;
    }

    public int getBytes() {
        return Bytes;
    }

    public void setBytes(int bytes) {
        Bytes = bytes;
    }

    public float getUnitPrice() {
        return UnitPrice;
    }

    public void setUnitPrice(float unitPrice) {
        UnitPrice = unitPrice;
    }






}
